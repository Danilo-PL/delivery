const {Router} = require ('express');
const rutas = Router();


module.exports = rutas;