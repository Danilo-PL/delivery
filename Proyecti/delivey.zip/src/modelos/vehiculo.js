const sequelize = require('sequelize');
const db = require('../configuracion/db');

const Vehiculo = db.define(
    "vehiculo",
    {
        vehiculo_tipo: {
            type: sequelize.ENUM('moto','carro','bicicleta'),
            allowNull: false,
            defaultValue: 'moto'
        },
        vehiculo_placa: {
            type: sequelize.STRING(8), 
            allowNull: true,
        },
        vehiculo_descripcion: {
            type: sequelize.TEXT, 
            allowNull: true,
        }
    },
    {
        tablename: "vehiculos"
    }
);

module.exports = Vehiculo;
