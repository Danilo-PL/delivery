const sequelize = require('sequelize');
const db = require('../configuracion/db');

const Ubicacion = db.define(
    "ubicacion",
    {
        latitud: {
            type: sequelize.FLOAT,
            allowNull: false,
        },
        longitud: {
            type: sequelize.FLOAT,
            allowNull: false,
        }
    },
    {
        tableName: "ubicaciones"
    }
);

module.exports = Ubicacion;
