const sequelize = require('sequelize');
const db = require('../configuracion/db');

const Venta = db.define(
    "venta",
    {
        fecha_venta:{
            type: sequelize.STRING(15),
            allowNull: false,
        },
        total:{
            type: sequelize.DOUBLE,
            allowNull: false,
        },
        estado_pago:{
            type: sequelize.ENUM('Pagado','Pendiente'),
            allowNull: true,
            defaultValue: 'Pagado'
        },
    },
    {
        tablename: "ventas"
    }
);

module.exports = Venta;