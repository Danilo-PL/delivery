const sequelize = require('sequelize');
const db = require('../configuracion/db');

const Restaurante = db.define(
    "restaurante",
    {
        nombre: {
            type: sequelize.STRING(100),
            allowNull: false,
        },
        direccion: {
            type: sequelize.TEXT,
            allowNull: false,
        },
        telefono: {
            type: sequelize.STRING(15),
            allowNull: false,
        }
    },
    {
        tableName: "restaurantes"
    }
);

module.exports = Restaurante;
