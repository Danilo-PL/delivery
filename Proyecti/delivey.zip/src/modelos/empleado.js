const sequelize = require('sequelize');
const db = require('../configuracion/db');

const Empleado = db.define(
    "empleado",
    {
        identidad:{
            type: sequelize.STRING(13),
            allowNull: false,
        },
        nombre:{
            type: sequelize.STRING(50),
            allowNull: false,
        },
        telefono:{
            type: sequelize.STRING(15),
            allowNull: false,
        },
        correo:{
            type: sequelize.STRING(50),
            allowNull: true,
        },
        cargo:{
            type: sequelize.STRING(50),
            allowNull: false,
        }
    },
    {
        tablename: "empleados"
    }
);

module.exports = Empleado;
