
import './App.css';
import Login from './componentes/login/login';

function App() {
  return (
    <Login>
      
    </Login>
   
  );
}

export default App;
